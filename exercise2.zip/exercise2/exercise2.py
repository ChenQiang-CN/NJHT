# -*- coding:UTF-8 -*-
# @time: 2021/8/5 9:38
# @autho: EmptyMoon
# @file: exercise2.py

import os
import time
import h5py
import numpy as np
import gdal, osr, gdalconst

def ReadHDF(hdf_path):
    """
    读取HDF格式数据
    返回 hdf_file, extend, bandName
    """
    hdf_file = h5py.File(hdf_path, 'r')
    extend = hdf_file.attrs['extend']
    bandName = list(hdf_file.keys())

    return hdf_file, extend, bandName

def writeTIFF(data, out_tif, extend, res):
    """
        将数组输出成tiff文件
        data 需要输出的数组
        out_tif 输出路径
        extend 经纬度范围
        res 分辨率
    """
    driver = gdal.GetDriverByName('GTiff')
    band_raster = driver.Create(out_tif, data.shape[1], data.shape[0], 1, gdal.GDT_Float32)
    band_raster.SetGeoTransform((extend[0], res, 0, extend[3], 0, -res))
    # 代码4326表示WGS84坐标
    outRasterSRS = osr.SpatialReference()
    outRasterSRS.ImportFromEPSG(4326)
    band_raster.SetProjection(outRasterSRS.ExportToWkt())
    # 获取数据集第一个波段，是从1开始，不是从0开始
    outband = band_raster.GetRasterBand(1)
    outband.WriteArray(data)

    return True

def toTIFF(hdf_path):
    """
        根据HDF不同波段的分辨率输出相应分斌率的tiff文件
    """
    hdf_file, extend, bandName = ReadHDF(hdf_path)
    for i in range(len(bandName)):
        data = hdf_file[bandName[i]][()]
        out_tif = '/'.join(hdf_path.split('/')[:-1]) + '/bands2tif/' + hdf_path.split('/')[-1] + '_' + bandName[i] + '.tif'
        if bandName[i] == 'B03':
            res = 0.005
            writeTIFF(data, out_tif, extend, res)
        elif bandName[i] == 'B01' or bandName[i] == 'B02' or bandName[i] == 'B04':
            res = 0.01
            writeTIFF(data, out_tif, extend, res)
        else:
            res = 0.02
            writeTIFF(data, out_tif, extend, res)
    return True

def resample(hdf_path):
    """
        对于非2km分辨率的波段进行重新样，变为2km分辨率
    """
    input = '/'.join(hdf_path.split('/')[:-1]) + '/bands2tif/'
    for filename in os.listdir(input):
        if 'B01' in filename or 'B02' in filename or 'B04' in filename:
            input_filename = os.path.join(input + filename)
            inputraster = gdal.Open(input_filename, gdal.GA_ReadOnly)
            inputTrans = inputraster.GetGeoTransform()
            inputProj = inputraster.GetProjection()
            width = inputraster.RasterXSize
            Height = inputraster.RasterYSize

            out_resample = input + 'resample/' + filename[:-4] + '_resample.tif'
            # 修改分辨率
            outputTrans = list(inputTrans)
            outputTrans[1] = 0.02
            outputTrans[5] = -0.02
            outputTrans = tuple(outputTrans)
            driver = gdal.GetDriverByName('GTiff')
            output = driver.Create(out_resample, width/2, Height/2, 1, gdal.GDT_Float32)
            output.SetGeoTransform(outputTrans)
            output.SetProjection(inputProj)

            gdal.ReprojectImage(inputraster, output, inputProj, inputProj, gdalconst.GRA_Bilinear)
        elif 'B03' in filename:
            input_filename = os.path.join(input + filename)
            inputraster = gdal.Open(input_filename, gdal.GA_ReadOnly)
            inputTrans = inputraster.GetGeoTransform()
            inputProj = inputraster.GetProjection()
            width = inputraster.RasterXSize
            Height = inputraster.RasterYSize

            out_resample = input + 'resample/' + filename[:-4] + '_resample.tif'
            # 修改分辨率
            outputTrans = list(inputTrans)
            outputTrans[1] = 0.02
            outputTrans[5] = -0.02
            outputTrans = tuple(outputTrans)
            driver = gdal.GetDriverByName('GTiff')
            output = driver.Create(out_resample, width/4, Height/4, 1, gdal.GDT_Float32)
            output.SetGeoTransform(outputTrans)
            output.SetProjection(inputProj)

            gdal.ReprojectImage(inputraster, output, inputProj, inputProj, gdalconst.GRA_Bilinear)

    return True

def clipRaster(hdf_path, shp_path):
    """
        进行矢量裁剪
    """
    path = '/'.join(hdf_path.split('/')[:-1]) + '/bands2tif/'
    for root, dirs, files in os.walk(path):
        for file in files:
            filename = os.path.join(root, file)
            inputraster = gdal.Open(filename)
            out_clip = '/'.join(hdf_path.split('/')[:-1]) + '/cliptiff/' + file[:-4] + '_clip.tif'
            gdal.Warp(out_clip, inputraster, format='GTiff', cutlineDSName=shp_path, cropToCutline=True, dstNodata=-9999)

    return True

def wipeCloud(hdf_path):
    """
        利用'B03 > 1200' 和 ’B05 > 2000‘的条件对B03和B04进行去云操作，
        为计算NDVI值做准备
    """
    path = '/'.join(hdf_path.split('/')[:-1]) + '/cliptiff/'
    for file in os.listdir(path):
        if 'B03_resample_clip' in file:
            filename = os.path.join(path, file)
            dataset = gdal.Open(filename)
            imdata_B03 = dataset.ReadAsArray()
            extend = dataset.GetGeoTransform()
        elif 'B05_clip' in file:
            filename = os.path.join(path, file)
            imdata_B05 = gdal.Open(filename).ReadAsArray()

    for file in os.listdir(path):
        if 'B03_resample_clip' in file or 'B04_resample_clip' in file:
            input_file = os.path.join(path, file)
            fileArray = gdal.Open(input_file).ReadAsArray()
            for i in range(imdata_B03.shape[0]):
                for j in range(imdata_B03.shape[1]):
                    if imdata_B03[i][j] > 1200 or imdata_B05[i][j] > 2800:
                        fileArray[i][j] = -9999
            out_nocloud = '/'.join(hdf_path.split('/')[:-1]) + '/nocloud/' + file[:-4] + '_oncloud.tif'
            writeTIFF(fileArray, out_nocloud, extend, 0.02)

    return True

def calNDVI(hdf_path):
    """
        计算NDVI值
    """
    path = '/'.join(hdf_path.split('/')[:-1]) + '/nocloud/'
    for file in os.listdir(path):
        if 'B03' in file:
            filename = os.path.join(path + file)
            dataset = gdal.Open(filename)
            imdata_red = dataset.ReadAsArray()
            extend = dataset.GetGeoTransform()
        elif 'B04' in file:
            filename = os.path.join(path + file)
            imdata_nir = gdal.Open(filename).ReadAsArray()

    NDVI = np.zeros((imdata_red.shape))
    for i in range(imdata_red.shape[0]):
        for j in range(imdata_red.shape[1]):
            if imdata_red[i][j] == -9999 or imdata_nir[i][j] == -9999:
                NDVI[i][j] = -9999
            else:
                NDVI[i][j] = (imdata_nir[i][j] - imdata_red[i][j]) / (imdata_nir[i][j] + imdata_red[i][j])

    out_NDVI = '/'.join(hdf_path.split('/')[:-1]) + '/NDVI.tif'
    writeTIFF(NDVI, out_NDVI, extend, 0.02)

    return True


if __name__ == '__main__':

    print('start time:', time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time())))

    hdf_path = 'E:/xuhuan/algorithm/data/HDF/202106280700.hdf'
    shp_path = 'E:/xuhuan/algorithm/data/SHP/CHN.shp'

    flag = toTIFF(hdf_path)
    if flag == True:
        print('-------所有波段成功转成tiff文件-------')
    else:
        print('-------所有波段转成tiff文件失败-------')

    flag = resample(hdf_path)
    if flag == True:
        print('-------重采样成功-------')
    else:
        print('-------重采样失败-------')

    flag = clipRaster(hdf_path, shp_path)
    if flag == True:
        print('-------裁剪成功-------')
    else:
        print('-------裁剪失败-------')

    flag = wipeCloud(hdf_path)
    if flag == True:
        print('-------去云成功-------')
    else:
        print('-------去云失败-------')

    flag = calNDVI(hdf_path)
    if flag == True:
        print('-------成功计算NDVI值-------')
    else:
        print('-------计算NDVI值失败-------')

    print('end time', time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time())))